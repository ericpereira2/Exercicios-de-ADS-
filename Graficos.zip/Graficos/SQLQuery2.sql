﻿
use dbProdutos;

DELETE FROM dbo.tbProdutos2;
INSERT INTO dbo.tbProdutos2 VALUES(1,'Computador',100,500,600);
INSERT INTO dbo.tbProdutos2 VALUES(2,'Monitor	',10,600,300);
INSERT INTO dbo.tbProdutos2 VALUES(3,'HD	',140,80,800);
INSERT INTO dbo.tbProdutos2 VALUES(4,'Mouse	',20,200,1000);
INSERT INTO dbo.tbProdutos2 VALUES(5,'Teclado	',10,25,500);
INSERT INTO dbo.tbProdutos2 VALUES(5,'Teclado Games',250,25,500);


SELECT * FROM dbo.tbProdutos2 ;